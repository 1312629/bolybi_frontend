var appComponents = angular.module('appComponents', ['appControllers']);

$.loadScript('js/components/home.component.js');
$.loadScript('js/components/login.component.js');
$.loadScript('js/components/server.component.js');
$.loadScript('js/components/svnavigationBar.component.js');
$.loadScript('js/components/svAllOrders.component.js');
$.loadScript('js/components/svNewOrders.component.js');
$.loadScript('js/components/svAllSneakers.component.js');
$.loadScript('js/components/svAddSneakers.component.js');
$.loadScript('js/components/svAllAcces.component.js');
$.loadScript('js/components/svAddAcces.component.js');
$.loadScript('js/components/svHome.component.js');
$.loadScript('js/components/main.component.js');
$.loadScript('js/components/about.component.js');
$.loadScript('js/components/products.component.js');
$.loadScript('js/components/viewProduct.component.js');