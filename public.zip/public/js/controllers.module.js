var appControllers = angular.module('appControllers', []);

$.loadScript('js/controllers/home.controller.js');
$.loadScript('js/controllers/login.controller.js');
$.loadScript('js/controllers/server.controller.js');
$.loadScript('js/controllers/svnavigationBar.controller.js');
$.loadScript('js/controllers/svAllOrders.controller.js');
$.loadScript('js/controllers/svNewOrders.controller.js');
$.loadScript('js/controllers/svAllSneakers.controller.js');
$.loadScript('js/controllers/svAddSneakers.controller.js');
$.loadScript('js/controllers/svAllAcces.controller.js');
$.loadScript('js/controllers/svAddAcces.controller.js');
$.loadScript('js/controllers/svHome.controller.js');
$.loadScript('js/controllers/main.controller.js');
$.loadScript('js/controllers/about.controller.js');
$.loadScript('js/controllers/products.controller.js');
$.loadScript('js/controllers/viewProduct.controller.js');
