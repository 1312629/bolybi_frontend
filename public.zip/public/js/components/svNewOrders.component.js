appComponents.component('svNewOrders', {
  templateUrl:  'partials/server/svNewOrders.html',
  controller: 'svNewOrdersController'
});