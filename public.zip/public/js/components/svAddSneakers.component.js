appComponents.component('svAddSneakers', {
  templateUrl:  'partials/server/svAddSneakers.html',
  controller: 'svAddSneakersController'
});