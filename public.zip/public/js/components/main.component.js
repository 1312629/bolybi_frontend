appComponents.component('main', {
  templateUrl:  'partials/main.html',
  controller: 'mainController'
});