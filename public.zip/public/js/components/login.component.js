appComponents.component('login', {
  templateUrl:  'partials/login.html',
  controller: 'loginController'
});