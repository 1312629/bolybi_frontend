appComponents.component('svAllAcces', {
  templateUrl:  'partials/server/svAllAcces.html',
  controller: 'svAllAccesController'
});