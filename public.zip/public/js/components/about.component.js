appComponents.component('about', {
  templateUrl:  'partials/about.html',
  controller: 'aboutController'
});