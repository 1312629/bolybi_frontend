appComponents.component('svHome', {
  templateUrl:  'partials/server/svHome.html',
  controller: 'svHomeController'
});