var appServices = angular.module('appServices', []);

$.loadScript('js/services/auth.service.js');
$.loadScript('js/services/sneakers.service.js');
$.loadScript('js/services/accessories.service.js');
$.loadScript('js/services/carts.service.js');
$.loadScript('js/services/orders.service.js');
$.loadScript('js/services/products.service.js');