appComponents.component('products', {
  templateUrl:  'partials/products.html',
  controller: 'productsController'
});