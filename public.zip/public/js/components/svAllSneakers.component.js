appComponents.component('svAllSneakers', {
  templateUrl:  'partials/server/svAllSneakers.html',
  controller: 'svAllSneakersController'
});