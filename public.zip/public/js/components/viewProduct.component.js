appComponents.component('viewProduct', {
  templateUrl:  'partials/viewProduct.html',
  controller: 'viewProductController'
});