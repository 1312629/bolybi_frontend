appComponents.component('home', {
  templateUrl:  'partials/home.html',
  controller: 'homeController'
});
