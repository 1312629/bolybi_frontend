appComponents.component('svnavigationBar', {
  templateUrl:  'partials/server/svnavigationBar.html',
  controller: 'svnavigationBarController'
});