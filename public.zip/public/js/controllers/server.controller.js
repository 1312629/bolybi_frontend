appControllers.controller('serverController', ['$scope', '$state',
	function($scope, $state) {
        angular.element(document).ready(function(){
//            $.loadScript("../js/dist/app.min.js");
//            $.loadScript("../js/dist/demo.js");
        })
	}
]);