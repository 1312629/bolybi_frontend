appComponents.component('svAddAcces', {
  templateUrl:  'partials/server/svAddAcces.html',
  controller: 'svAddAccesController'
});