appControllers.controller('aboutController', ['$scope', '$state',
	function($scope, $state) {
        
    }
]);