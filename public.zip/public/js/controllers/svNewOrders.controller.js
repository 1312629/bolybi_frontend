appControllers.controller('svNewOrdersController', ['$scope', '$state',
	function($scope, $state) {
	}
]);