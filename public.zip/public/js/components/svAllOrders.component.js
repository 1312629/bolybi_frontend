appComponents.component('svAllOrders', {
  templateUrl:  'partials/server/svAllOrders.html',
  controller: 'svAllOrdersController'
});