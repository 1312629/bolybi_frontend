appComponents.component('server', {
  templateUrl:  'partials/server/server.html',
  controller: 'serverController'
});
